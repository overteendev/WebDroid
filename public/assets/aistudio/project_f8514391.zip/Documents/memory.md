# Personalization Memory — Biswanath Das (@skykoderhere)

## 1. Demographics and Identity
- Real name: Biswanath Das.
- Preferred name: Sky / Skye.
- Canonical username across social media and developer platforms: `@skykoderhere`.
- GitHub: https://github.com/skykoderhere
- Replace older handles such as `skykoderhere` variants, `Sky`, `Skye`, and `PawDeveloper` with `@skykoderhere` when referring to the user's current preferred handle.
- General residence: West Bengal, India. Do not assume a precise current location.
- Languages: Bengali, English, and Hindi.
- Roles: Engineer, Developer, Student.
- Education: Completed Higher Secondary with 70%+ in PCM.
- The user is still deciding between B.Sc. Computer Science, B.Tech, and BCA. Do not assume a final decision.
- Previously mentioned overall degree budget: approximately ₹2 lakh. Prioritize affordable options and verify current fees, eligibility, and admission rules before advising.

## 2. Interests and Preferences

### Technology and Development
- Sustained interests include software development, Android development, web development, open-source contributions, GitHub, APK modification, app development, websites, and practical technical learning.
- Technologies and tools explored include HTML, CSS, JavaScript, Java, Kotlin, Smali, Python, Firebase, Git/GitHub, Telegram bots, Termux, SPCK Editor, MT Manager, PWA, GitHub Pages, Vercel, Netlify, and Cloudflare.
- Experience includes Android SDK, APK modification, music/video web-app APIs, Piped/Invidious, YouTube embeds, and music metadata APIs.
- For debugging and manual patching, inspect actual code, repository structure, application versions, and method signatures. Never invent APIs, source targets, or Smali instructions.

### Projects and Brands
- Project ecosystem: Pawjects, PawGram, PawGram X, PawTube, Pawtify, PawDownloader, PawIDE, and PawDevs.
- The user is the founder and lead developer of Pawjects, established in 2025.
- The user develops Android and web applications and maintains open-source GitHub repositories.
- Developer presence:
  - GitHub: https://github.com/skykoderhere
  - Portfolio: https://skye.is-a.dev
  - Communities/projects: @pawjects and @pawgramapp
- Use `@skykoderhere` as the canonical personal username. Project-specific brand handles and URLs should remain distinct when they refer to separate projects.

### Design Preferences
- Prefers compact, minimal, responsive interfaces.
- Likes Android Material You / Monet-inspired styling, AMOLED dark themes, light themes, clear visual hierarchy, and useful controls.
- Usually dislikes glassmorphism, excessive gradients, oversized cards or text, and visual clutter.
- For Pawtify, the established direction is an AMOLED-dark interface with Spotify-inspired green accents, mobile-first responsiveness, larger touch-friendly controls, and a cohesive professional music-app design.
- Follow the latest project-specific design brief when it conflicts with general preferences.

### Development Workflow
- Often works using Android/mobile development tools.
- Provide mobile-friendly, step-by-step instructions, exact file paths, complete copy-paste-ready code, and explanations of root causes.
- Preserve existing architecture, backend systems, and working functionality when fixing projects.
- Prefer accurate, practical implementation guidance over speculative suggestions.

### Education and Career
- Interested in technology-related higher education and software-development careers.
- When comparing B.Sc. Computer Science, B.Tech, and BCA, explain eligibility, syllabus, practical depth, costs, admission routes, career options, and trade-offs.
- Clearly separate confirmed facts from assumptions and verify current official information when needed.
- Prefers remote work.

## 3. Relationships

### Girlfriend — Separate Profile
- The user's girlfriend has been referred to as Soumi and/or Ria in previous conversations.
- These names refer to the girlfriend, not the user. Never call the user Soumi or Ria.
- She is interested in aviation and is pursuing cabin-crew training.
- Aviation and cabin-crew course decisions, institute fees, interview preparation, and hospitality-versus-aviation questions belong to her profile unless explicitly stated otherwise.
- Never merge her education, career plans, personal details, or preferences with the user's technology education and career planning.

## 4. Dated Events, Projects, and Plans

- **2025:** Pawjects was established; the user serves as founder and lead developer.
- **2026-06-18:** Developer profile documented Android development, web development, open-source contributions, technical skills, and online developer profiles.
- **2026-10-21:** The user was considering B.Sc. Computer Science, B.Tech, and BCA, with a previously stated degree budget of approximately ₹2 lakh. No final degree choice is established.
- **2026-10-21:** The project ecosystem included Pawjects, PawGram, PawGram X, PawTube, Pawtify, PawDownloader, PawIDE, and PawDevs.
- **2026-10-21:** Pawtify's design direction emphasized AMOLED dark styling, Spotify-inspired green accents, mobile-first responsiveness, touch-friendly controls, and a consistent professional music-app interface.
- **Ongoing:** The user develops Android and web applications, maintains GitHub repositories, explores open-source projects, and learns practical technical skills.
- **Current identity preference:** Use `@skykoderhere` as the canonical personal username across social media and developer-platform references, including GitHub. This preference does not establish that external account usernames have already been changed.

## 5. Instructions for the Assistant

### Accuracy and Reasoning
- Be accurate, direct, practical, and willing to challenge incorrect assumptions.
- Explain uncertainty and trade-offs.
- Verify current or version-specific facts when useful.
- Never fabricate technical details, repository contents, APIs, code behavior, or source targets.
- Preserve distinctions between confirmed information, assumptions, and recommendations.
- Do not assume that an undecided education or career choice has been finalized.

### Response Style
- User instruction: "Always over explain and keep to the point with proper ture knowledge and choose challenging over agreement".
- Provide enough explanation to make difficult topics understandable while avoiding filler, empty reassurance, and fabricated certainty.
- Use structured Markdown, headings, lists, and tables when appropriate.
- Use emojis creatively and moderately when they improve communication.
- Keep communication crisp, direct, and practical while showing appropriate enthusiasm and curiosity.
- Challenge assumptions rather than agreeing automatically.

### Project and Workflow Rules
- Inspect actual code, repository contents, application versions, and method signatures before proposing technical fixes.
- Never invent APIs, source targets, or Smali instructions.
- Preserve existing architecture, backends, and working functionality when fixing projects.
- Give mobile-friendly instructions, exact paths, and complete copy-paste-ready code when appropriate.
- Follow the latest project-specific requirements over general design preferences.
- For degree comparisons, cover eligibility, curriculum, practical depth, costs, admission routes, careers, and trade-offs. Verify current official information when necessary.
- Keep the user's technology education and career separate from the girlfriend's aviation education and career.

### Identity and Naming
- Use `@skykoderhere` as the user's canonical personal username in future profile summaries and references.
- Use https://github.com/skykoderhere as the preferred GitHub profile URL.
- Do not claim that usernames on external platforms have been changed unless that change has actually been completed and verified.
- Do not call the user Soumi or Ria; those names refer to the girlfriend.

Imported from ChatGPT